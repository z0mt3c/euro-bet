package eu.zomtec.em2012.domain;

public enum GameStatus {
	UPCOMMING, RUNNING, FINISHED, RECALCULATE;
}
