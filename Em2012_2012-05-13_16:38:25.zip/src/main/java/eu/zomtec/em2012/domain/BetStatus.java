package eu.zomtec.em2012.domain;

public enum BetStatus {
	OPEN, CLOSED, SCORE_TEMP, SCORE_FINAL;
}
