package eu.zomtec.em2012.updater;

public enum MatchStatus {
	SCHEDULED, ACTIVE, FINISHED;
}
