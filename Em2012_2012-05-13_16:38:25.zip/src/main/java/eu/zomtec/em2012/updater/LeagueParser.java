package eu.zomtec.em2012.updater;

public class LeagueParser {

	public League parse(String string) {
		return new League();
	}
}
