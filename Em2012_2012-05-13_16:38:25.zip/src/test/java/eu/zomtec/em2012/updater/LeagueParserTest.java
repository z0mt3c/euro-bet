package eu.zomtec.em2012.updater;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.validator.util.privilegedactions.GetClassLoader;
import org.junit.Assert;
import org.junit.Test;

public class LeagueParserTest {
	private LeagueParser leagueParser = new LeagueParser();
	
	private static String JSON_TEXT = null;
	
	static {
		try {
			final InputStream inputStream = LeagueParser.class.getClassLoader().getResourceAsStream("./kicker-demo.json");
			JSON_TEXT = IOUtils.toString(inputStream);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void test() {
		Assert.assertTrue(StringUtils.isNotBlank(JSON_TEXT));
		final League league = leagueParser.parse(JSON_TEXT);
		Assert.assertNotNull(league);
	}
}
