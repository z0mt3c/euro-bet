package eu.zomtec.em2012.domain;

import org.springframework.roo.addon.dod.RooDataOnDemand;

@RooDataOnDemand(entity = BetUserRole.class)
public class BetUserRoleDataOnDemand {
}
