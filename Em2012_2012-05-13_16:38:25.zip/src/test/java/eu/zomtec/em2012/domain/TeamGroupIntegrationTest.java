package eu.zomtec.em2012.domain;

import org.junit.Test;
import org.springframework.roo.addon.test.RooIntegrationTest;

@RooIntegrationTest(entity = TeamGroup.class)
public class TeamGroupIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
