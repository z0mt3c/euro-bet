package eu.zomtec.em2012.domain;

import org.junit.Test;
import org.springframework.roo.addon.test.RooIntegrationTest;

@RooIntegrationTest(entity = BetUser.class)
public class BetUserIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
