package eu.zomtec.em2012.domain;

import org.junit.Test;
import org.springframework.roo.addon.test.RooIntegrationTest;

@RooIntegrationTest(entity = GameGroup.class)
public class GameGroupIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
