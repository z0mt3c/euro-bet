package eu.zomtec.em2012.domain;

import org.junit.Test;
import org.springframework.roo.addon.test.RooIntegrationTest;

@RooIntegrationTest(entity = BetUserRole.class)
public class BetUserRoleIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
